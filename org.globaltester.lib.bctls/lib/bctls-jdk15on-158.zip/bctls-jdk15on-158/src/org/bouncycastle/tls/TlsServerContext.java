package org.bouncycastle.tls;

/**
 * Marker interface to distinguish a TLS server context.
 */
public interface TlsServerContext
    extends TlsContext
{
}
